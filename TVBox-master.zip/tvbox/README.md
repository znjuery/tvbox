### 1. TVBox 开源版  
- TVBox1.0.0 ，[GitHub社区](https://github.com/CatVodTVOfficial/TVBoxOSC) 根据官方代码仓生成的安卓应用。  
- 移植了猫影视V6的内核，可以无缝对接电视直播、影视剧点播站源规则，就是说原来的接口可以直接用。  
- 本地功能，这个版本也具备了，只需要开启存储权限，在配置地址栏输入本地规则地址即可。  
- 设置——配置地址——输入你的站源规则——确定即可；  

### 2. 下载地址
 - [TVbox开源版](https://wws.lanzouv.com/b03j4ulyh#999)   
 - [欢迎大家加群一起交流学习分享---点击直接加入群](https://jq.qq.com/?_wv=1027&k=KhLg7JXX)  
